import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

export const NowSection = () => {
  return (
    <section className="py-6 border-b border-[#E5E7EB] dark:border-[#1E293B] transition-colors">
      <div className="max-w-3xl mx-auto px-4 sm:px-6">
        <Link
          to="/about"
          className="group flex items-center justify-between p-3 px-4 rounded-xl bg-[#FFFFFF] dark:bg-[#131B2E] border border-[#E5E7EB] dark:border-[#1E293B] hover:border-[#6F88B5]/60 transition-all duration-200 ease-[cubic-bezier(0.22,1,0.36,1)] hover:-translate-y-0.5 hover:shadow-xs active:scale-[0.99] text-xs cursor-pointer"
        >
          <div className="flex items-center gap-2.5 overflow-hidden">
            <span className="relative flex h-2 w-2 shrink-0">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#6F88B5] opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-[#6F88B5]"></span>
            </span>
            <span className="text-[10px] font-mono font-bold tracking-wider text-[#111827] dark:text-[#F9FAFB] uppercase shrink-0">
              NOW:
            </span>
            <span className="text-[#4B5563] dark:text-[#94A3B8] font-light truncate">
              Currently building SONG ISLE · Exploring AI / Developer Tools / Web & Android
            </span>
          </div>

          <div className="flex items-center gap-1 font-mono text-[11px] text-[#6F88B5] shrink-0 pl-2">
            <span>About</span>
            <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform duration-200" />
          </div>
        </Link>
      </div>
    </section>
  );
};
