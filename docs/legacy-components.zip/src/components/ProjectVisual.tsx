import type { Project } from '../data/portfolioData';

interface ProjectVisualProps {
  project: Project;
  className?: string;
  isHero?: boolean;
}

export const ProjectVisual = ({ project, className = '', isHero = false }: ProjectVisualProps) => {
  const baseClass = 'w-full transition-all duration-300 ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.025] group-hover:brightness-[1.03]';
  const containerClass = isHero
    ? `${baseClass} aspect-[16/9] max-h-[360px]`
    : `${baseClass} aspect-[16/9]`;

  // LIZHANG - Android Mobile App Mockup Visual
  if (project.category === 'android') {
    return (
      <div
        className={`${containerClass} bg-gradient-to-br from-[#1E293B] to-[#0F172A] rounded-xl overflow-hidden relative flex items-center justify-center p-3 sm:p-4 border border-[#334155]/40 select-none ${className}`}
      >
        <div className="absolute w-36 h-36 rounded-full bg-[#6F88B5]/20 blur-2xl pointer-events-none -top-8 -right-8" />

        {/* Smartphone Frame */}
        <div className="w-48 sm:w-56 bg-[#0B0F19] rounded-xl border border-[#475569]/60 p-2 shadow-2xl relative">
          {/* Status Bar */}
          <div className="flex items-center justify-between px-1 pb-1.5 text-[8px] font-mono text-[#94A3B8]">
            <span>09:41</span>
            <div className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-[#6F88B5]"></span>
              <span>5G</span>
            </div>
          </div>

          {/* App Header */}
          <div className="bg-[#1E293B] rounded p-1.5 mb-1.5 border border-[#334155]/60 flex items-center justify-between">
            <div>
              <div className="text-[10px] font-medium text-white">礼金收支总览</div>
              <div className="text-[7px] font-mono text-[#94A3B8]">本地离线加密账本</div>
            </div>
            <div className="text-[9px] font-mono font-bold text-[#6F88B5]">+￥12,800</div>
          </div>

          {/* Ledger Items preview */}
          <div className="space-y-1">
            <div className="bg-[#172033] p-1.5 rounded flex items-center justify-between border border-[#334155]/40">
              <div className="flex items-center gap-1.5">
                <span className="w-3.5 h-3.5 rounded bg-[#6F88B5]/20 text-[#6F88B5] text-[8px] flex items-center justify-center font-bold">
                  收
                </span>
                <div>
                  <div className="text-[9px] text-gray-200">婚礼贺礼 · 张志远</div>
                  <div className="text-[7px] text-gray-400">2026.09.06 · 微信/现金</div>
                </div>
              </div>
              <span className="text-[9px] font-mono font-medium text-emerald-400">+￥1,000</span>
            </div>

            <div className="bg-[#172033] p-1.5 rounded flex items-center justify-between border border-[#334155]/40">
              <div className="flex items-center gap-1.5">
                <span className="w-3.5 h-3.5 rounded bg-rose-500/20 text-rose-400 text-[8px] flex items-center justify-center font-bold">
                  送
                </span>
                <div>
                  <div className="text-[9px] text-gray-200">满月志庆 · 李明哲</div>
                  <div className="text-[7px] text-gray-400">2026.08.20 · 亲朋往来</div>
                </div>
              </div>
              <span className="text-[9px] font-mono font-medium text-rose-400">-￥800</span>
            </div>
          </div>
        </div>

        <div className="absolute bottom-2 right-2 text-[9px] font-mono text-[#94A3B8] bg-[#0F172A]/80 px-1.5 py-0.5 rounded border border-[#334155]/40 backdrop-blur-xs">
          Android · Kotlin · Compose
        </div>
      </div>
    );
  }

  // Lumina Engine - Interactive WebGL Canvas Mockup Visual
  if (project.category === 'web') {
    return (
      <div
        className={`${containerClass} bg-[#0A0F1D] rounded-xl overflow-hidden relative flex flex-col justify-between p-3 sm:p-4 border border-[#1E293B] select-none ${className}`}
      >
        {/* Browser Top Bar */}
        <div className="flex items-center justify-between pb-1.5 border-b border-[#1E293B]/80 text-[#64748B] text-[9px] font-mono">
          <div className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-rose-500/80"></span>
            <span className="w-2 h-2 rounded-full bg-amber-500/80"></span>
            <span className="w-2 h-2 rounded-full bg-emerald-500/80"></span>
            <span className="ml-1.5 text-gray-400">lumina.canvas/v0.4</span>
          </div>
          <span className="text-[#38BDF8] text-[8px] font-mono">60.0 FPS · 124K NODES</span>
        </div>

        {/* Abstract Topology Nodes and Connections */}
        <div className="relative flex-1 flex items-center justify-center my-1">
          <svg className="w-full h-full" viewBox="0 0 300 120" fill="none">
            <path d="M 40 60 Q 90 20 150 60 T 260 60" stroke="#1E3A5F" strokeWidth="1.5" />
            <path d="M 80 90 Q 150 40 220 90" stroke="#1E3A5F" strokeWidth="1" strokeDasharray="3 3" />
            <path d="M 150 60 L 150 15" stroke="#38BDF8" strokeWidth="1" strokeOpacity="0.4" />
            <path d="M 150 60 L 80 90" stroke="#38BDF8" strokeWidth="1" strokeOpacity="0.6" />
            <path d="M 150 60 L 220 90" stroke="#38BDF8" strokeWidth="1" strokeOpacity="0.6" />

            <circle cx="150" cy="60" r="7" fill="#0284C7" />
            <circle cx="150" cy="60" r="12" stroke="#38BDF8" strokeWidth="1" strokeOpacity="0.6" />
            <circle cx="40" cy="60" r="3.5" fill="#38BDF8" />
            <circle cx="150" cy="15" r="4.5" fill="#7DD3FC" />
            <circle cx="80" cy="90" r="4" fill="#38BDF8" />
            <circle cx="220" cy="90" r="4" fill="#38BDF8" />
            <circle cx="260" cy="60" r="3.5" fill="#38BDF8" />
          </svg>
        </div>

        <div className="flex items-center justify-between text-[8px] font-mono text-[#64748B]">
          <span>Quadtree Culling: Active</span>
          <span className="text-[#38BDF8]">WebGL Pipeline: OK</span>
        </div>
      </div>
    );
  }

  // TypoCraft CLI - Terminal Interface Visual
  if (project.category === 'tools') {
    return (
      <div
        className={`${containerClass} bg-[#121417] rounded-xl overflow-hidden relative flex flex-col p-3 sm:p-4 border border-[#27272A] font-mono text-xs select-none ${className}`}
      >
        <div className="flex items-center justify-between pb-1.5 border-b border-[#27272A] text-[#71717A] text-[9px]">
          <div className="flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-[#52525B]"></span>
            <span className="w-1.5 h-1.5 rounded-full bg-[#52525B]"></span>
            <span className="w-1.5 h-1.5 rounded-full bg-[#52525B]"></span>
            <span className="ml-1 text-[#A1A1AA]">typocraft review --ast</span>
          </div>
          <span className="text-emerald-400 text-[8px]">Rust v1.82</span>
        </div>

        <div className="pt-2 space-y-1 text-[9px] leading-relaxed text-[#D4D4D8] flex-1 overflow-hidden">
          <div className="text-[#71717A]">$ typocraft analyze ./src --output markdown</div>
          <div className="text-emerald-400">✔ Parsed 42 files (18,420 LOC) in 142ms via Tree-sitter</div>
          <div className="text-amber-300">! Warning: 2 dead exports detected</div>
          <div className="text-[#60A5FA]">i Extracted 18 API interface contracts to doc/api.md</div>
        </div>

        <div className="text-[8px] text-[#71717A] flex items-center justify-between pt-1 border-t border-[#27272A]/80">
          <span>AST Stream: OK</span>
          <span className="text-emerald-400">Exit Code: 0</span>
        </div>
      </div>
    );
  }

  // Kura Store - Distributed KV Cluster Visual
  if (project.category === 'systems') {
    return (
      <div
        className={`${containerClass} bg-[#0A1128] rounded-xl overflow-hidden relative flex flex-col justify-between p-3 sm:p-4 border border-[#1C2541] select-none ${className}`}
      >
        <div className="flex items-center justify-between text-[9px] font-mono text-[#8D99AE]">
          <span>Raft Cluster: 5 Nodes</span>
          <span className="text-[#48E5C2]">Leader: node-01</span>
        </div>

        <div className="grid grid-cols-5 gap-1.5 my-auto py-1">
          {['node-01', 'node-02', 'node-03', 'node-04', 'node-05'].map((name, i) => (
            <div
              key={name}
              className={`p-1.5 rounded border text-center font-mono ${
                i === 0
                  ? 'bg-[#1C2541] border-[#48E5C2] text-[#48E5C2]'
                  : 'bg-[#111A35] border-[#1C2541] text-[#8D99AE]'
              }`}
            >
              <div className="text-[9px] font-bold">{i === 0 ? 'LEADER' : 'FOLLOWER'}</div>
              <div className="text-[7px] opacity-70">N0{i + 1}</div>
            </div>
          ))}
        </div>

        <div className="flex items-center justify-between text-[8px] font-mono text-[#8D99AE] pt-1 border-t border-[#1C2541]">
          <span>WAL Replay: 100%</span>
          <span className="text-[#48E5C2]">gRPC Stream: Active</span>
        </div>
      </div>
    );
  }

  // AI & Assistant Visual
  return (
    <div
      className={`${containerClass} bg-[#13111C] rounded-xl overflow-hidden relative flex flex-col justify-between p-3 sm:p-4 border border-[#2D2640] select-none ${className}`}
    >
      <div className="flex items-center justify-between text-[9px] font-mono text-[#A594F9]">
        <span>Local RAG · Ollama Agent</span>
        <span className="text-emerald-400">Vector Indexed</span>
      </div>

      <div className="my-auto space-y-1.5 p-2 bg-[#1C1829] rounded border border-[#3A3252]">
        <div className="text-[8px] font-mono text-[#A594F9]/80">Query: "如何配置 Compose 离线优先？"</div>
        <div className="text-[8px] text-gray-300 font-sans leading-snug line-clamp-2">
          检索到 3 个本地笔记切片：建议使用 Room + Flow 进行单向数据流装配...
        </div>
      </div>

      <div className="flex items-center justify-between text-[8px] font-mono text-[#7D7495]">
        <span>Latency: 280ms (Local)</span>
        <span className="text-[#A594F9]">SQLite-VSS</span>
      </div>
    </div>
  );
};
