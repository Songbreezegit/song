import { Link } from 'react-router-dom';
import { ArrowRight, BookOpen, Layers } from 'lucide-react';
import { PROFILE } from '../data/portfolioData';
import { usePointerShift } from '../hooks/usePointerShift';

export const Hero = () => {
  const { handleMouseMove, handleMouseLeave, style: pointerStyle } = usePointerShift({
    maxOffset: 3.5,
    dampening: 0.12,
  });

  return (
    <section className="relative pt-12 pb-12 sm:pt-16 sm:pb-16 border-b border-[#E5E7EB] dark:border-[#1E293B] overflow-hidden transition-colors">
      {/* Calm, very subtle ambient mist texture with gentle breathing rhythm */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[520px] h-[280px] bg-radial from-[#6F88B5]/12 via-[#E5E7EB]/30 dark:via-[#1A233A]/40 to-transparent rounded-full blur-3xl pointer-events-none -z-10 animate-breathe" />

      <div className="max-w-3xl mx-auto px-4 sm:px-6 text-center">
        {/* Logo Symbol with staggered entry & subtle desktop pointer shift */}
        <div
          className="inline-flex mb-5 animate-hero-logo cursor-default"
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
        >
          <div
            style={pointerStyle}
            className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-[#FFFFFF] dark:bg-[#131B2E] border border-[#E5E7EB] dark:border-[#1E293B] p-2 flex items-center justify-center shadow-[0_4px_20px_rgba(111,136,181,0.08)] dark:shadow-[0_4px_24px_rgba(0,0,0,0.4)] hover:shadow-[0_6px_28px_rgba(111,136,181,0.14)] dark:hover:shadow-[0_6px_32px_rgba(0,0,0,0.6)] hover:border-[#6F88B5]/40 transition-shadow duration-300"
          >
            <img
              src="/logo.png"
              alt="松屿 SONG ISLE"
              className="w-full h-full object-contain rounded-xl select-none"
            />
          </div>
        </div>

        {/* Brand Names */}
        <div className="space-y-1 mb-3.5">
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-serif font-medium text-[#111827] dark:text-[#F9FAFB] tracking-wider animate-hero-name">
            {PROFILE.name}
          </h1>
          <p className="text-xs sm:text-sm font-mono tracking-[0.25em] text-[#64748B] dark:text-[#94A3B8] uppercase animate-hero-sub">
            {PROFILE.englishName}
          </p>
        </div>

        {/* Quiet Editorial Tagline */}
        <p className="text-sm sm:text-base text-[#4B5563] dark:text-[#94A3B8] font-light max-w-xl mx-auto leading-relaxed mb-6 animate-hero-tagline">
          {PROFILE.tagline}
        </p>

        {/* Two CTAs with Clear Hierarchy: Primary solid, Secondary outlined */}
        <div className="flex flex-wrap items-center justify-center gap-3 animate-hero-cta">
          <Link
            to="/articles"
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#111827] dark:bg-[#F9FAFB] hover:bg-[#1F2937] dark:hover:bg-white text-white dark:text-[#111827] text-xs font-medium transition-all duration-200 ease-[cubic-bezier(0.22,1,0.36,1)] hover:-translate-y-0.5 hover:shadow-md active:scale-[0.98] group cursor-pointer"
          >
            <BookOpen className="w-3.5 h-3.5 text-[#9CA3AF] dark:text-[#64748B] group-hover:text-white dark:group-hover:text-[#111827] transition-colors" />
            <span>Explore Articles</span>
            <ArrowRight className="w-3 h-3 text-[#9CA3AF] dark:text-[#64748B] group-hover:translate-x-1 transition-transform duration-200 ease-[cubic-bezier(0.22,1,0.36,1)]" />
          </Link>

          <Link
            to="/projects"
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#FFFFFF] dark:bg-[#131B2E] hover:bg-[#F3F4F6] dark:hover:bg-[#1A233A] text-[#374151] dark:text-[#CBD5E1] hover:text-[#111827] dark:hover:text-white border border-[#E5E7EB] dark:border-[#1E293B] hover:border-[#CBD5E1] dark:hover:border-[#334155] text-xs font-medium transition-all duration-200 ease-[cubic-bezier(0.22,1,0.36,1)] hover:-translate-y-0.5 active:scale-[0.98] cursor-pointer"
          >
            <Layers className="w-3.5 h-3.5 text-[#64748B] dark:text-[#94A3B8]" />
            <span>View Projects</span>
          </Link>
        </div>
      </div>
    </section>
  );
};
