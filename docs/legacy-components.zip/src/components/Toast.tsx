import { Check } from 'lucide-react';

interface ToastProps {
  message: string | null;
  onClose?: () => void;
}

export function Toast({ message }: ToastProps) {
  if (!message) return null;

  return (
    <aside
      aria-label="Notification"
      className="fixed bottom-6 right-6 z-50 flex items-center gap-2 px-4 py-2.5 bg-[#111827] text-white dark:bg-white dark:text-[#111827] rounded-full shadow-lg border border-neutral-700/20 text-sm font-medium animate-in fade-in slide-in-from-bottom-3 duration-200"
    >
      <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 dark:text-emerald-600 flex items-center justify-center shrink-0">
        <Check className="w-3.5 h-3.5" />
      </span>
      <span>{message}</span>
    </aside>
  );
}
