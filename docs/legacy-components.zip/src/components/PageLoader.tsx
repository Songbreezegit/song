import { useState, useEffect } from 'react';

interface PageLoaderProps {
  isLoading: boolean;
  onFinish?: () => void;
}

export const PageLoader = ({ isLoading, onFinish }: PageLoaderProps) => {
  const [visible, setVisible] = useState(() => {
    if (typeof window !== 'undefined') {
      return !window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    }
    return true;
  });
  const [isFadingOut, setIsFadingOut] = useState(false);

  useEffect(() => {
    if (!visible) return;

    let finishTimer: ReturnType<typeof setTimeout>;
    let cleanupTimer: ReturnType<typeof setTimeout>;

    if (!isLoading) {
      finishTimer = setTimeout(() => {
        setIsFadingOut(true);
      }, 50);

      cleanupTimer = setTimeout(() => {
        setVisible(false);
        if (onFinish) onFinish();
      }, 700);

      return () => {
        clearTimeout(finishTimer);
        clearTimeout(cleanupTimer);
      };
    } else {
      // Safety fallback: maximum 1200ms loading duration to never block the user
      const maxSafetyTimer = setTimeout(() => {
        setIsFadingOut(true);
        setTimeout(() => {
          setVisible(false);
          if (onFinish) onFinish();
        }, 500);
      }, 1100);

      return () => clearTimeout(maxSafetyTimer);
    }
  }, [isLoading, onFinish, visible]);

  if (!visible) return null;

  return (
    <div
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#0B0F17] transition-all duration-500 ease-[cubic-bezier(0.22,1,0.36,1)] select-none ${
        isFadingOut ? 'opacity-0 scale-[0.98] pointer-events-none' : 'opacity-100 scale-100'
      }`}
      role="status"
      aria-live="polite"
      aria-label="松屿 SONG ISLE 页面正在载入"
    >
      {/* Subtle calm ambient glow with breathing rhythm */}
      <div className="absolute w-72 h-72 rounded-full bg-[#6F88B5]/20 blur-3xl pointer-events-none animate-breathe" />

      {/* Logo & Brand Identity */}
      <div className="relative flex flex-col items-center">
        {/* Logo Symbol */}
        <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-[#111827] border border-[#1F2937] p-2 flex items-center justify-center shadow-2xl animate-hero-logo">
          <img
            src="/logo.png"
            alt="松屿 SONG ISLE Logo"
            className="w-full h-full object-contain rounded-xl"
          />
        </div>

        {/* Brand Text */}
        <div className="mt-5 text-center space-y-1">
          <h2 className="font-serif text-xl sm:text-2xl font-medium tracking-widest text-[#F9FAFB] animate-hero-name">
            松 屿
          </h2>
          <p className="text-[10px] font-mono tracking-[0.3em] text-[#9CA3AF] uppercase animate-hero-sub">
            S O N G &nbsp; I S L E
          </p>
        </div>

        {/* Very subtle line glow accent */}
        <div className="w-12 h-[1px] bg-gradient-to-r from-transparent via-[#6F88B5]/60 to-transparent mt-4 animate-hero-tagline" />
      </div>
    </div>
  );
};
