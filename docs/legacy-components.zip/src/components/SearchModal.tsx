import { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, X, BookOpen, Layers, ArrowRight } from 'lucide-react';
import { ARTICLES, PROJECTS } from '../data/portfolioData';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SearchModal = ({ isOpen, onClose }: SearchModalProps) => {
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  const handleClose = useCallback(() => {
    setQuery('');
    onClose();
  }, [onClose]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        if (isOpen) {
          handleClose();
        }
      }
      if (e.key === 'Escape' && isOpen) {
        handleClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, handleClose]);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const trimmed = query.trim().toLowerCase();

  const matchedArticles = trimmed
    ? ARTICLES.filter(
        (a) =>
          a.title.toLowerCase().includes(trimmed) ||
          a.subtitle.toLowerCase().includes(trimmed) ||
          a.tags.some((t) => t.toLowerCase().includes(trimmed)) ||
          a.category.toLowerCase().includes(trimmed)
      )
    : ARTICLES.slice(0, 3);

  const matchedProjects = trimmed
    ? PROJECTS.filter(
        (p) =>
          p.title.toLowerCase().includes(trimmed) ||
          p.subtitle.toLowerCase().includes(trimmed) ||
          p.techStack.some((t) => t.toLowerCase().includes(trimmed)) ||
          p.description.toLowerCase().includes(trimmed)
      )
    : PROJECTS.slice(0, 3);

  const handleSelect = (path: string) => {
    navigate(path);
    handleClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 px-4">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-[#0B0F19]/60 backdrop-blur-xs transition-opacity"
        onClick={handleClose}
      />

      {/* Modal Box */}
      <div className="relative w-full max-w-xl bg-[#FFFFFF] dark:bg-[#131B2E] border border-[#E5E7EB] dark:border-[#1E293B] rounded-2xl shadow-2xl overflow-hidden z-10 animate-in fade-in zoom-in-95 duration-150">
        {/* Search Header */}
        <div className="flex items-center px-4 py-3.5 border-b border-[#E5E7EB] dark:border-[#1E293B] gap-3">
          <Search className="w-4 h-4 text-[#9CA3AF] shrink-0" />
          <input
            ref={inputRef}
            type="text"
            placeholder="搜索文章、项目、工具或技术标签..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full bg-transparent text-sm text-[#111827] dark:text-[#F9FAFB] placeholder-[#9CA3AF] focus:outline-none"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 text-[#9CA3AF] hover:text-[#111827] dark:hover:text-white"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
          <kbd className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] font-mono text-[#9CA3AF] bg-[#F1F3F5] dark:bg-[#1A233A] rounded border border-[#E5E7EB] dark:border-[#2A3654]">
            ESC
          </kbd>
        </div>

        {/* Results Body */}
        <div className="max-h-[60vh] overflow-y-auto p-3 space-y-4">
          {/* Articles Section */}
          <div>
            <div className="px-2 pb-2 text-[10px] font-mono tracking-widest text-[#9CA3AF] uppercase flex items-center justify-between">
              <span>Articles / 文章 ({matchedArticles.length})</span>
            </div>
            {matchedArticles.length === 0 ? (
              <div className="px-3 py-2 text-xs text-[#9CA3AF]">无匹配文章</div>
            ) : (
              <div className="space-y-1">
                {matchedArticles.map((article) => (
                  <button
                    key={article.id}
                    onClick={() => handleSelect(`/articles/${article.slug}`)}
                    className="w-full text-left p-2.5 rounded-xl hover:bg-[#F3F4F6] dark:hover:bg-[#1A233A] transition-colors flex items-center justify-between group cursor-pointer"
                  >
                    <div className="flex items-center gap-2.5 pr-2">
                      <BookOpen className="w-3.5 h-3.5 text-[#6F88B5] shrink-0" />
                      <div>
                        <div className="text-xs font-medium text-[#111827] dark:text-[#F9FAFB] group-hover:text-[#6F88B5] transition-colors line-clamp-1">
                          {article.title}
                        </div>
                        <div className="text-[11px] text-[#64748B] dark:text-[#94A3B8] font-light">
                          {article.date} · {article.category}
                        </div>
                      </div>
                    </div>
                    <ArrowRight className="w-3 h-3 text-[#9CA3AF] group-hover:translate-x-0.5 transition-transform shrink-0" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Projects Section */}
          <div className="pt-2 border-t border-[#E5E7EB]/60 dark:border-[#1E293B]/60">
            <div className="px-2 pb-2 text-[10px] font-mono tracking-widest text-[#9CA3AF] uppercase flex items-center justify-between">
              <span>Projects / 项目与作品 ({matchedProjects.length})</span>
            </div>
            {matchedProjects.length === 0 ? (
              <div className="px-3 py-2 text-xs text-[#9CA3AF]">无匹配项目</div>
            ) : (
              <div className="space-y-1">
                {matchedProjects.map((project) => (
                  <button
                    key={project.id}
                    onClick={() => handleSelect(`/projects/${project.slug}`)}
                    className="w-full text-left p-2.5 rounded-xl hover:bg-[#F3F4F6] dark:hover:bg-[#1A233A] transition-colors flex items-center justify-between group cursor-pointer"
                  >
                    <div className="flex items-center gap-2.5 pr-2">
                      <Layers className="w-3.5 h-3.5 text-[#6F88B5] shrink-0" />
                      <div>
                        <div className="text-xs font-medium text-[#111827] dark:text-[#F9FAFB] group-hover:text-[#6F88B5] transition-colors flex items-center gap-1.5">
                          <span>{project.title}</span>
                          <span className="text-[11px] font-normal text-[#64748B] dark:text-[#94A3B8]">
                            {project.subtitle}
                          </span>
                        </div>
                        <div className="text-[11px] text-[#64748B] dark:text-[#94A3B8] font-mono">
                          {project.techStack.slice(0, 3).join(' · ')}
                        </div>
                      </div>
                    </div>
                    <ArrowRight className="w-3 h-3 text-[#9CA3AF] group-hover:translate-x-0.5 transition-transform shrink-0" />
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
