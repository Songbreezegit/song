interface BadgeProps {
  label: string;
  category?: string;
  className?: string;
  size?: 'sm' | 'md';
}

const getCategoryStyles = (categoryName?: string) => {
  if (!categoryName) return 'bg-gray-100 text-gray-700 border-gray-200 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-700';

  const lower = categoryName.toLowerCase();

  // AI category: Cool blue
  if (lower.includes('ai') || lower.includes('ocr') || lower.includes('rag') || lower.includes('llm')) {
    return 'bg-sky-50 text-sky-700 border-sky-200 dark:bg-sky-950/50 dark:text-sky-300 dark:border-sky-800/80';
  }

  // Tools & CLI: Indigo / Slate
  if (lower.includes('tool') || lower.includes('cli') || lower.includes('rust') || lower.includes('vim') || lower.includes('ast')) {
    return 'bg-indigo-50 text-indigo-700 border-indigo-200 dark:bg-indigo-950/50 dark:text-indigo-300 dark:border-indigo-800/80';
  }

  // Tutorial: Warm amber / beige
  if (lower.includes('tutorial') || lower.includes('教程') || lower.includes('指南')) {
    return 'bg-amber-50 text-amber-800 border-amber-200 dark:bg-amber-950/50 dark:text-amber-300 dark:border-amber-800/80';
  }

  // Android: Emerald green
  if (lower.includes('android') || lower.includes('kotlin') || lower.includes('compose') || lower.includes('mobile')) {
    return 'bg-emerald-50 text-emerald-800 border-emerald-200 dark:bg-emerald-950/50 dark:text-emerald-300 dark:border-emerald-800/80';
  }

  // Systems / KV / Raft: Violet / Purple
  if (lower.includes('systems') || lower.includes('raft') || lower.includes('grpc') || lower.includes('kv')) {
    return 'bg-violet-50 text-violet-800 border-violet-200 dark:bg-violet-950/50 dark:text-violet-300 dark:border-violet-800/80';
  }

  // Development / Web / TS: Teal / Slate Blue
  if (lower.includes('dev') || lower.includes('web') || lower.includes('typescript') || lower.includes('架构')) {
    return 'bg-teal-50 text-teal-800 border-teal-200 dark:bg-teal-950/50 dark:text-teal-300 dark:border-teal-800/80';
  }

  return 'bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700';
};

export const Badge = ({ label, category, className = '', size = 'sm' }: BadgeProps) => {
  const colorStyle = getCategoryStyles(category || label);
  const sizeStyle = size === 'sm' ? 'px-2 py-0.5 text-[11px]' : 'px-2.5 py-1 text-xs';

  return (
    <span
      className={`inline-flex items-center font-mono rounded border transition-colors ${colorStyle} ${sizeStyle} ${className}`}
    >
      {label}
    </span>
  );
};
