import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { ArrowUpRight, ArrowRight } from 'lucide-react';
import { PROJECTS } from '../data/portfolioData';
import { ProjectVisual } from '../components/ProjectVisual';
import { Badge } from '../components/Badge';
import { GithubIcon } from '../components/Icons';

export const ProjectsPage = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categories = [
    { id: 'all', label: 'All Projects / 全部' },
    { id: 'android', label: 'Android' },
    { id: 'web', label: 'Web' },
    { id: 'ai', label: 'AI' },
    { id: 'tools', label: 'Tools / CLI' },
    { id: 'systems', label: 'Systems' },
  ];

  const filteredProjects = useMemo(() => {
    if (selectedCategory === 'all') return PROJECTS;
    return PROJECTS.filter((p) => p.category === selectedCategory);
  }, [selectedCategory]);

  return (
    <div className="py-12 sm:py-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        {/* Page Header */}
        <header className="mb-8 space-y-2">
          <span className="text-xs font-mono tracking-widest text-[#6F88B5] uppercase font-bold animate-hero-sub">
            PROJECTS & ARCHIVE
          </span>
          <h1 className="text-3xl sm:text-4xl font-serif font-medium text-[#111827] dark:text-[#F9FAFB] tracking-tight animate-hero-name">
            项目与开源作品
          </h1>
          <p className="text-sm sm:text-base text-[#64748B] dark:text-[#94A3B8] font-light max-w-xl leading-relaxed animate-hero-tagline">
            涵盖 Android 原生应用、Web 图形内核、本地 AI 与系统工具，记录真实构建的代码成果。
          </p>
        </header>

        {/* Category Filter Pills */}
        <div className="flex flex-wrap items-center gap-1.5 mb-8">
          {categories.map((cat) => {
            const active = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1 rounded-lg text-xs font-mono transition-all duration-180 ease-[cubic-bezier(0.22,1,0.36,1)] hover:-translate-y-0.5 active:scale-[0.96] cursor-pointer border ${
                  active
                    ? 'bg-[#111827] dark:bg-[#F9FAFB] text-white dark:text-[#111827] border-[#111827] dark:border-[#F9FAFB] font-medium shadow-2xs'
                    : 'bg-[#FFFFFF] dark:bg-[#131B2E] text-[#4B5563] dark:text-[#94A3B8] border-[#E5E7EB] dark:border-[#1E293B] hover:bg-[#F3F4F6] dark:hover:bg-[#1A233A] hover:border-[#CBD5E1] dark:hover:border-[#334155]'
                }`}
              >
                {cat.label}
              </button>
            );
          })}
        </div>

        {/* Two-Column Grid of Unified Height Cards with smooth filter animation */}
        <div
          key={selectedCategory}
          className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-in fade-in zoom-in-[0.99] duration-200"
        >
          {filteredProjects.map((project, idx) => (
            <article
              key={project.id}
              className="group bg-[#FFFFFF] dark:bg-[#131B2E] border border-[#E5E7EB] dark:border-[#1E293B] hover:border-[#CBD5E1] dark:hover:border-[#334155] rounded-2xl overflow-hidden transition-all duration-250 ease-[cubic-bezier(0.22,1,0.36,1)] hover:-translate-y-1 hover:shadow-lg flex flex-col justify-between"
              style={{ transitionDelay: `${Math.min(idx * 40, 160)}ms` }}
            >
              <div>
                {/* 16:9 Visual Thumbnail Mockup with strictly clipped zoom */}
                <Link to={`/projects/${project.slug}`} className="block overflow-hidden rounded-t-2xl">
                  <ProjectVisual project={project} />
                </Link>

                {/* Card Info */}
                <div className="p-4 sm:p-5 space-y-2">
                  <div className="flex items-baseline justify-between gap-2">
                    <Link
                      to={`/projects/${project.slug}`}
                      className="font-serif text-base sm:text-lg font-medium text-[#111827] dark:text-[#F9FAFB] group-hover:text-[#6F88B5] transition-colors duration-180 flex items-baseline gap-2"
                    >
                      <span>{project.title}</span>
                      <span className="text-xs font-sans font-normal text-[#64748B] dark:text-[#94A3B8]">
                        {project.subtitle}
                      </span>
                    </Link>
                    <span className="text-[11px] font-mono text-[#9CA3AF]">
                      {project.year}
                    </span>
                  </div>

                  {/* One-liner intro */}
                  <p className="text-xs text-[#4B5563] dark:text-[#94A3B8] leading-relaxed font-light line-clamp-2">
                    {project.description}
                  </p>

                  {/* Semantic Tech Badges */}
                  <div className="pt-1.5 flex flex-wrap gap-1.5">
                    {project.techStack.slice(0, 4).map((tech) => (
                      <Badge key={tech} label={tech} category={project.category} size="sm" />
                    ))}
                  </div>
                </div>
              </div>

              {/* Action Links: Details as main entrance, GitHub as icon */}
              <div className="px-4 sm:px-5 pb-4 pt-2 flex items-center justify-between border-t border-[#E5E7EB]/60 dark:border-[#1E293B]/60 text-xs font-mono">
                <Link
                  to={`/projects/${project.slug}`}
                  className="inline-flex items-center gap-1 text-xs font-medium text-[#111827] dark:text-[#F9FAFB] hover:text-[#6F88B5] dark:hover:text-[#6F88B5] transition-colors group/link"
                >
                  <span>Details / 详情</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover/link:translate-x-1 transition-transform duration-200" />
                </Link>

                <div className="flex items-center gap-3">
                  {project.liveUrl && (
                    <a
                      href={project.liveUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[#6F88B5] hover:underline text-[11px] flex items-center gap-0.5"
                    >
                      <span>Demo</span>
                      <ArrowUpRight className="w-3 h-3" />
                    </a>
                  )}

                  <a
                    href={project.githubUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[#64748B] dark:text-[#94A3B8] hover:text-[#111827] dark:hover:text-white p-1 rounded hover:bg-[#F1F3F5] dark:hover:bg-[#1A233A] hover:scale-110 active:scale-95 transition-all duration-180"
                    title="在 GitHub 查看源码"
                  >
                    <GithubIcon className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </div>
  );
};
