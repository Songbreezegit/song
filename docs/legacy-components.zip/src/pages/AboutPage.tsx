import { useState } from 'react';
import { ArrowUpRight, Mail, Copy, Check } from 'lucide-react';
import { PROFILE } from '../data/portfolioData';
import { GithubIcon, XTwitterIcon } from '../components/Icons';

export const AboutPage = () => {
  const [copied, setCopied] = useState(false);

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(PROFILE.contact.email);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="py-12 sm:py-20">
      <article className="max-w-2xl mx-auto px-4 sm:px-6 space-y-10 page-reveal">
        {/* Page Header */}
        <header className="space-y-3 pb-6 border-b border-[#E5E7EB] dark:border-[#1E293B]">
          <span className="text-xs font-mono tracking-widest text-[#6F88B5] uppercase font-bold animate-hero-sub">
            ABOUT
          </span>
          <h1 className="text-3xl sm:text-4xl font-serif font-medium text-[#111827] dark:text-[#F9FAFB] tracking-tight animate-hero-name">
            {PROFILE.name} &nbsp;
            <span className="text-base sm:text-lg font-sans font-normal text-[#64748B] dark:text-[#94A3B8]">
              / {PROFILE.englishName}
            </span>
          </h1>

          {/* Digital Space Overview */}
          <div className="pt-2 text-sm sm:text-base text-[#374151] dark:text-[#CBD5E1] font-light leading-relaxed animate-hero-tagline">
            <p className="p-4 bg-[#FFFFFF] dark:bg-[#131B2E] border border-[#E5E7EB] dark:border-[#1E293B] rounded-xl shadow-2xs">
              {PROFILE.siteIntro}
            </p>
          </div>
        </header>

        {/* CURRENTLY Section (Single Source of Truth) */}
        <section className="space-y-3.5">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-mono uppercase tracking-widest text-[#111827] dark:text-[#F9FAFB] font-bold">
              CURRENTLY / 近况与探索
            </h2>
            <span className="text-[11px] font-mono text-[#9CA3AF]">
              {PROFILE.currently.date}
            </span>
          </div>

          <div className="p-5 bg-[#FFFFFF] dark:bg-[#131B2E] border border-[#E5E7EB] dark:border-[#1E293B] rounded-2xl space-y-3.5">
            <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1 pb-3 border-b border-[#E5E7EB]/70 dark:border-[#1E293B]/70">
              <span className="text-xs font-mono text-[#9CA3AF]">Building</span>
              <span className="text-xs sm:text-sm font-medium text-[#111827] dark:text-[#F9FAFB]">
                {PROFILE.currently.building}
              </span>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1 pb-3 border-b border-[#E5E7EB]/70 dark:border-[#1E293B]/70">
              <span className="text-xs font-mono text-[#9CA3AF]">Learning</span>
              <span className="text-xs sm:text-sm text-[#374151] dark:text-[#CBD5E1]">
                {PROFILE.currently.learning}
              </span>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1">
              <span className="text-xs font-mono text-[#9CA3AF]">Exploring</span>
              <span className="text-xs sm:text-sm text-[#374151] dark:text-[#CBD5E1]">
                {PROFILE.currently.exploring}
              </span>
            </div>
          </div>
        </section>

        {/* Contact & External Links */}
        <section className="space-y-3.5 pt-2 border-t border-[#E5E7EB] dark:border-[#1E293B]">
          <h2 className="text-xs font-mono uppercase tracking-widest text-[#111827] dark:text-[#F9FAFB] font-bold">
            CONTACT / 交流与链接
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* GitHub Card */}
            <a
              href={PROFILE.contact.github}
              target="_blank"
              rel="noopener noreferrer"
              className="p-3.5 bg-[#FFFFFF] dark:bg-[#131B2E] hover:bg-[#F9FAFB] dark:hover:bg-[#1A233A] border border-[#E5E7EB] dark:border-[#1E293B] hover:border-[#6F88B5] rounded-xl flex items-center justify-between transition-colors group"
            >
              <div className="flex items-center gap-2.5">
                <GithubIcon className="w-4 h-4 text-[#374151] dark:text-[#CBD5E1] group-hover:text-[#111827] dark:group-hover:text-white" />
                <div>
                  <div className="text-xs font-medium text-[#111827] dark:text-[#F9FAFB]">GitHub</div>
                  <div className="text-[10px] font-mono text-[#64748B] dark:text-[#94A3B8]">Songbreezegit</div>
                </div>
              </div>
              <ArrowUpRight className="w-3.5 h-3.5 text-[#9CA3AF] group-hover:text-[#111827] dark:group-hover:text-white transition-colors" />
            </a>

            {/* X (Twitter) Card */}
            <a
              href={PROFILE.contact.x}
              target="_blank"
              rel="noopener noreferrer"
              className="p-3.5 bg-[#FFFFFF] dark:bg-[#131B2E] hover:bg-[#F9FAFB] dark:hover:bg-[#1A233A] border border-[#E5E7EB] dark:border-[#1E293B] hover:border-[#6F88B5] rounded-xl flex items-center justify-between transition-colors group"
            >
              <div className="flex items-center gap-2.5">
                <XTwitterIcon className="w-3.5 h-3.5 text-[#374151] dark:text-[#CBD5E1] group-hover:text-[#111827] dark:group-hover:text-white" />
                <div>
                  <div className="text-xs font-medium text-[#111827] dark:text-[#F9FAFB]">X</div>
                  <div className="text-[10px] font-mono text-[#64748B] dark:text-[#94A3B8]">@song_breezed</div>
                </div>
              </div>
              <ArrowUpRight className="w-3.5 h-3.5 text-[#9CA3AF] group-hover:text-[#111827] dark:group-hover:text-white transition-colors" />
            </a>

            {/* Email Card with Copy Action */}
            <div className="p-3.5 bg-[#FFFFFF] dark:bg-[#131B2E] border border-[#E5E7EB] dark:border-[#1E293B] rounded-xl flex items-center justify-between">
              <div className="flex items-center gap-2.5 overflow-hidden">
                <Mail className="w-4 h-4 text-[#6F88B5] shrink-0" />
                <div className="overflow-hidden">
                  <div className="text-xs font-medium text-[#111827] dark:text-[#F9FAFB]">Email</div>
                  <div className="text-[10px] font-mono text-[#64748B] dark:text-[#94A3B8] truncate select-all">
                    {PROFILE.contact.email}
                  </div>
                </div>
              </div>
              <button
                onClick={handleCopyEmail}
                className="p-1 text-xs text-[#64748B] dark:text-[#94A3B8] hover:text-[#111827] dark:hover:text-white hover:bg-[#F1F3F5] dark:hover:bg-[#1A233A] rounded transition-colors cursor-pointer shrink-0"
                title="复制邮箱地址"
              >
                {copied ? (
                  <Check className="w-3.5 h-3.5 text-emerald-500" />
                ) : (
                  <Copy className="w-3.5 h-3.5" />
                )}
              </button>
            </div>
          </div>
        </section>
      </article>
    </div>
  );
};
