import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { Hero } from '../components/Hero';
import { NowSection } from '../components/NowSection';
import { ARTICLES, PROJECTS } from '../data/portfolioData';
import { ProjectVisual } from '../components/ProjectVisual';
import { Badge } from '../components/Badge';
import { GithubIcon } from '../components/Icons';
import { ScrollReveal } from '../components/ScrollReveal';

export const HomePage = () => {
  const latestArticles = ARTICLES.slice(0, 4);
  const selectedProjects = PROJECTS.slice(0, 4);

  return (
    <div>
      {/* 1. Hero */}
      <Hero />

      {/* 2. Latest Articles (Editorial list) */}
      <ScrollReveal delayMs={40}>
        <section className="py-12 sm:py-16 border-b border-[#E5E7EB] dark:border-[#1E293B] transition-colors">
          <div className="max-w-3xl mx-auto px-4 sm:px-6">
            <div className="flex items-baseline justify-between mb-6 pb-2.5 border-b border-[#E5E7EB] dark:border-[#1E293B]">
              <div>
                <span className="text-[11px] font-mono tracking-widest text-[#6F88B5] uppercase font-semibold">
                  LATEST ARTICLES
                </span>
                <h2 className="text-xl sm:text-2xl font-serif font-medium text-[#111827] dark:text-[#F9FAFB] mt-0.5">
                  近期文章与技术笔记
                </h2>
              </div>
              <Link
                to="/articles"
                className="inline-flex items-center gap-1 text-xs font-mono text-[#64748B] dark:text-[#94A3B8] hover:text-[#111827] dark:hover:text-white transition-colors group"
              >
                <span>View All</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform duration-200" />
              </Link>
            </div>

            {/* Editorial Article Timeline with Staggered Hover */}
            <div className="divide-y divide-[#E5E7EB] dark:divide-[#1E293B]">
              {latestArticles.map((article) => (
                <Link
                  key={article.id}
                  to={`/articles/${article.slug}`}
                  className="group block py-4 first:pt-0 last:pb-0 transition-all duration-200 ease-[cubic-bezier(0.22,1,0.36,1)] hover:translate-x-1"
                >
                  <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1 sm:gap-4 mb-1">
                    <div className="flex items-baseline gap-3">
                      <span className="text-xs font-mono text-[#9CA3AF] shrink-0">
                        {article.date.slice(5).replace('-', '.')}
                      </span>
                      <h3 className="text-sm sm:text-base font-serif font-medium text-[#111827] dark:text-[#F9FAFB] group-hover:text-[#6F88B5] transition-colors leading-snug flex items-center gap-1.5">
                        <span>{article.title}</span>
                        <ArrowRight className="w-3 h-3 text-[#6F88B5] opacity-0 -translate-x-1 group-hover:opacity-100 group-hover:translate-x-0.5 transition-all duration-200 shrink-0" />
                      </h3>
                    </div>
                    <div className="shrink-0 sm:self-auto self-start pl-8 sm:pl-0">
                      <Badge label={article.category} category={article.category} size="sm" />
                    </div>
                  </div>
                  <p className="text-xs text-[#64748B] dark:text-[#94A3B8] line-clamp-1 pl-8 font-light">
                    {article.subtitle}
                  </p>
                </Link>
              ))}
            </div>
          </div>
        </section>
      </ScrollReveal>

      {/* 3. Selected Projects (Two-column grid) */}
      <ScrollReveal delayMs={60}>
        <section className="py-12 sm:py-16 border-b border-[#E5E7EB] dark:border-[#1E293B] transition-colors">
          <div className="max-w-4xl mx-auto px-4 sm:px-6">
            <div className="flex items-baseline justify-between mb-6 pb-2.5 border-b border-[#E5E7EB] dark:border-[#1E293B]">
              <div>
                <span className="text-[11px] font-mono tracking-widest text-[#6F88B5] uppercase font-semibold">
                  SELECTED PROJECTS
                </span>
                <h2 className="text-xl sm:text-2xl font-serif font-medium text-[#111827] dark:text-[#F9FAFB] mt-0.5">
                  精选作品与实验
                </h2>
              </div>
              <Link
                to="/projects"
                className="inline-flex items-center gap-1 text-xs font-mono text-[#64748B] dark:text-[#94A3B8] hover:text-[#111827] dark:hover:text-white transition-colors group"
              >
                <span>View All</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform duration-200" />
              </Link>
            </div>

            {/* Two-Column Grid of Projects with Restrained Lift */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {selectedProjects.map((project) => (
                <article
                  key={project.id}
                  className="group bg-[#FFFFFF] dark:bg-[#131B2E] border border-[#E5E7EB] dark:border-[#1E293B] hover:border-[#CBD5E1] dark:hover:border-[#334155] rounded-2xl overflow-hidden transition-all duration-250 ease-[cubic-bezier(0.22,1,0.36,1)] hover:-translate-y-1 hover:shadow-md flex flex-col justify-between"
                >
                  <div>
                    <Link to={`/projects/${project.slug}`} className="block overflow-hidden rounded-t-2xl">
                      <ProjectVisual project={project} />
                    </Link>

                    <div className="p-4 sm:p-5 space-y-2">
                      <div className="flex items-baseline justify-between gap-2">
                        <Link
                          to={`/projects/${project.slug}`}
                          className="font-serif text-base sm:text-lg font-medium text-[#111827] dark:text-[#F9FAFB] group-hover:text-[#6F88B5] transition-colors flex items-baseline gap-1.5"
                        >
                          <span>{project.title}</span>
                          <span className="text-xs font-sans font-normal text-[#64748B] dark:text-[#94A3B8]">
                            {project.subtitle}
                          </span>
                        </Link>
                        <span className="text-[11px] font-mono text-[#9CA3AF]">
                          {project.year}
                        </span>
                      </div>

                      <p className="text-xs text-[#4B5563] dark:text-[#94A3B8] leading-relaxed font-light line-clamp-2">
                        {project.description}
                      </p>

                      <div className="pt-1.5 flex flex-wrap gap-1.5">
                        {project.techStack.slice(0, 3).map((tech) => (
                          <Badge key={tech} label={tech} category={project.category} size="sm" />
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="px-4 sm:px-5 pb-4 pt-2 flex items-center justify-between border-t border-[#E5E7EB]/60 dark:border-[#1E293B]/60 text-xs font-mono">
                    <Link
                      to={`/projects/${project.slug}`}
                      className="inline-flex items-center gap-1 text-xs font-medium text-[#111827] dark:text-[#F9FAFB] hover:text-[#6F88B5] transition-colors group/link"
                    >
                      <span>Details / 详情</span>
                      <ArrowRight className="w-3.5 h-3.5 group-hover/link:translate-x-1 transition-transform duration-200" />
                    </Link>

                    <a
                      href={project.githubUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[#64748B] dark:text-[#94A3B8] hover:text-[#111827] dark:hover:text-white p-1 rounded hover:bg-[#F1F3F5] dark:hover:bg-[#1A233A] hover:scale-110 active:scale-95 transition-all duration-180"
                      title="在 GitHub 查看源码"
                    >
                      <GithubIcon className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>
      </ScrollReveal>

      {/* 4. Now Section (Single line prompt) */}
      <ScrollReveal delayMs={80}>
        <NowSection />
      </ScrollReveal>
    </div>
  );
};
