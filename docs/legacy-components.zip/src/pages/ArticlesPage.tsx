import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Search } from 'lucide-react';
import { ARTICLES } from '../data/portfolioData';
import { Badge } from '../components/Badge';

export const ArticlesPage = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categories = [
    { id: 'all', label: 'All' },
    { id: 'tutorial', label: 'Tutorial / 教程' },
    { id: 'ai', label: 'AI 实践' },
    { id: 'development', label: 'Development / 开发' },
    { id: 'tools', label: 'Tools / 工具' },
    { id: 'systems', label: 'Systems / 系统' },
  ];

  const filteredArticles = useMemo(() => {
    return ARTICLES.filter((article) => {
      const matchCategory =
        selectedCategory === 'all' || article.categorySlug === selectedCategory;
      const matchQuery =
        searchQuery.trim() === '' ||
        article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        article.subtitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
        article.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchCategory && matchQuery;
    });
  }, [searchQuery, selectedCategory]);

  const articlesByYear = useMemo(() => {
    const groups: { [year: string]: typeof ARTICLES } = {};
    filteredArticles.forEach((article) => {
      if (!groups[article.year]) {
        groups[article.year] = [];
      }
      groups[article.year].push(article);
    });
    return groups;
  }, [filteredArticles]);

  const years = Object.keys(articlesByYear).sort((a, b) => Number(b) - Number(a));

  return (
    <div className="py-12 sm:py-16">
      <div className="max-w-3xl mx-auto px-4 sm:px-6">
        {/* Editorial Header */}
        <header className="mb-8 space-y-2">
          <span className="text-xs font-mono tracking-widest text-[#6F88B5] uppercase font-bold animate-hero-sub">
            ARTICLES & ARCHIVE
          </span>
          <h1 className="text-3xl sm:text-4xl font-serif font-medium text-[#111827] dark:text-[#F9FAFB] tracking-tight animate-hero-name">
            文章与数字档案
          </h1>
          <p className="text-sm sm:text-base text-[#64748B] dark:text-[#94A3B8] font-light max-w-xl leading-relaxed animate-hero-tagline">
            Ideas, tools, experiments and things I find worth sharing.
          </p>
        </header>

        {/* Search & Category Filter Controls */}
        <div className="space-y-3.5 mb-10">
          {/* Search Box */}
          <div className="relative">
            <Search className="w-4 h-4 text-[#9CA3AF] absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="搜索文章标题、关键词或标签..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-[#FFFFFF] dark:bg-[#131B2E] border border-[#E5E7EB] dark:border-[#1E293B] rounded-xl text-xs sm:text-sm text-[#111827] dark:text-[#F9FAFB] placeholder-[#9CA3AF] focus:outline-none focus:border-[#6F88B5] transition-all duration-200 shadow-2xs"
            />
          </div>

          {/* Category Pills */}
          <div className="flex flex-wrap items-center gap-1.5 pt-0.5">
            {categories.map((cat) => {
              const active = selectedCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-3 py-1 rounded-lg text-xs font-mono transition-all duration-180 ease-[cubic-bezier(0.22,1,0.36,1)] hover:-translate-y-0.5 active:scale-[0.96] cursor-pointer border ${
                    active
                      ? 'bg-[#111827] dark:bg-[#F9FAFB] text-white dark:text-[#111827] border-[#111827] dark:border-[#F9FAFB] font-medium shadow-2xs'
                      : 'bg-[#FFFFFF] dark:bg-[#131B2E] text-[#4B5563] dark:text-[#94A3B8] border-[#E5E7EB] dark:border-[#1E293B] hover:bg-[#F3F4F6] dark:hover:bg-[#1A233A] hover:border-[#CBD5E1] dark:hover:border-[#334155]'
                  }`}
                >
                  {cat.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Editorial Article List Grouped by Year with smooth presence transition */}
        {years.length === 0 ? (
          <div className="py-16 text-center text-xs font-mono text-[#9CA3AF] border border-dashed border-[#E5E7EB] dark:border-[#1E293B] rounded-xl">
            未检索到匹配的文章内容
          </div>
        ) : (
          <div
            key={`${selectedCategory}-${searchQuery}`}
            className="space-y-10 transition-all duration-250 ease-[cubic-bezier(0.22,1,0.36,1)] animate-in fade-in zoom-in-[0.99] duration-200"
          >
            {years.map((year) => (
              <section key={year} className="space-y-5">
                {/* Year Marker */}
                <div className="flex items-center gap-3">
                  <span className="font-serif text-xl sm:text-2xl font-bold text-[#111827] dark:text-[#F9FAFB]">
                    {year}
                  </span>
                  <div className="flex-1 h-[1px] bg-[#E5E7EB] dark:bg-[#1E293B]" />
                </div>

                {/* Articles in this year */}
                <div className="divide-y divide-[#E5E7EB] dark:divide-[#1E293B]">
                  {articlesByYear[year].map((article, idx) => (
                    <article
                      key={article.id}
                      className="py-5 first:pt-1 last:pb-1 group transition-all duration-200 ease-[cubic-bezier(0.22,1,0.36,1)] hover:translate-x-1"
                      style={{ transitionDelay: `${Math.min(idx * 30, 150)}ms` }}
                    >
                      <Link to={`/articles/${article.slug}`} className="block space-y-2">
                        <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1 sm:gap-4">
                          <div className="flex items-baseline gap-3">
                            <span className="text-xs font-mono text-[#9CA3AF] shrink-0">
                              {article.date.slice(5).replace('-', '.')}
                            </span>
                            <h2 className="font-serif text-base sm:text-lg font-medium text-[#111827] dark:text-[#F9FAFB] group-hover:text-[#6F88B5] transition-colors duration-180 leading-snug">
                              {article.title}
                            </h2>
                          </div>
                          <div className="shrink-0 sm:self-auto self-start pl-8 sm:pl-0">
                            <Badge label={article.category} category={article.category} size="sm" />
                          </div>
                        </div>

                        <p className="text-xs sm:text-sm text-[#4B5563] dark:text-[#94A3B8] font-light leading-relaxed pl-8">
                          {article.subtitle}
                        </p>

                        <div className="flex items-center gap-2 pl-8 pt-1 text-[11px] font-mono text-[#9CA3AF]">
                          <div className="flex flex-wrap gap-1.5">
                            {article.tags.map((tag) => (
                              <span
                                key={tag}
                                className="px-1.5 py-0.5 rounded bg-[#F1F3F5] dark:bg-[#1A233A] text-[#64748B] dark:text-[#94A3B8] border border-[#E5E7EB] dark:border-[#243048]"
                              >
                                #{tag}
                              </span>
                            ))}
                          </div>
                          <span className="ml-auto text-[#64748B] dark:text-[#94A3B8] group-hover:text-[#111827] dark:group-hover:text-white group-hover:translate-x-1 transition-all duration-200 font-medium">
                            Read →
                          </span>
                        </div>
                      </Link>
                    </article>
                  ))}
                </div>
              </section>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
