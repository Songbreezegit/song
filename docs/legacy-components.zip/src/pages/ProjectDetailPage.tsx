import { useParams, Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, ArrowUpRight, ExternalLink, CheckCircle2, Layers, Cpu } from 'lucide-react';
import { PROJECTS } from '../data/portfolioData';
import { ProjectVisual } from '../components/ProjectVisual';
import { Badge } from '../components/Badge';
import { GithubIcon } from '../components/Icons';

export const ProjectDetailPage = () => {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();

  const project = PROJECTS.find((p) => p.slug === slug);

  if (!project) {
    return (
      <div className="py-24 max-w-2xl mx-auto px-4 text-center space-y-4">
        <h1 className="text-xl font-serif text-[#111827] dark:text-white">项目未找到</h1>
        <p className="text-sm text-[#64748B] dark:text-[#94A3B8]">所请求的项目不存在或已被调整。</p>
        <button
          onClick={() => navigate('/projects')}
          className="px-4 py-2 bg-[#111827] dark:bg-white text-white dark:text-[#111827] rounded-lg text-xs font-mono cursor-pointer"
        >
          返回项目列表
        </button>
      </div>
    );
  }

  return (
    <div className="py-10 sm:py-16">
      <article className="max-w-3xl mx-auto px-4 sm:px-6 space-y-8 page-reveal">
        {/* Navigation Back */}
        <div>
          <Link
            to="/projects"
            className="inline-flex items-center gap-1.5 text-xs font-mono text-[#64748B] dark:text-[#94A3B8] hover:text-[#111827] dark:hover:text-white transition-colors group"
          >
            <ArrowLeft className="w-3.5 h-3.5 group-hover:-translate-x-1 transition-transform duration-200" />
            <span>Projects / 全部项目</span>
          </Link>
        </div>

        {/* Project Header */}
        <header className="space-y-3 pb-6 border-b border-[#E5E7EB] dark:border-[#1E293B]">
          <div className="flex items-center gap-2.5 animate-hero-sub">
            <Badge label={project.categoryLabel} category={project.category} size="md" />
            <span className="text-xs font-mono text-[#9CA3AF]">{project.year}</span>
          </div>

          <h1 className="text-2xl sm:text-3xl md:text-4xl font-serif font-medium text-[#111827] dark:text-[#F9FAFB] tracking-tight animate-hero-name">
            {project.title} &nbsp;
            <span className="text-base sm:text-lg font-sans font-normal text-[#64748B] dark:text-[#94A3B8]">
              {project.subtitle}
            </span>
          </h1>

          <p className="text-sm sm:text-base text-[#4B5563] dark:text-[#CBD5E1] font-light leading-relaxed animate-hero-tagline">
            {project.tagline}
          </p>

          {/* Quick Action Links */}
          <div className="flex flex-wrap items-center gap-3 pt-1.5 animate-hero-cta">
            <a
              href={project.githubUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#111827] dark:bg-[#F9FAFB] hover:bg-[#1F2937] dark:hover:bg-white text-white dark:text-[#111827] text-xs font-mono transition-all duration-200 ease-[cubic-bezier(0.22,1,0.36,1)] hover:-translate-y-0.5 active:scale-[0.98] shadow-2xs group"
            >
              <GithubIcon className="w-3.5 h-3.5" />
              <span>GitHub Repository</span>
              <ArrowUpRight className="w-3 h-3 text-gray-400 dark:text-gray-600 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform duration-200" />
            </a>

            {project.liveUrl && (
              <a
                href={project.liveUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#FFFFFF] dark:bg-[#131B2E] hover:bg-[#F3F4F6] dark:hover:bg-[#1A233A] text-[#374151] dark:text-[#CBD5E1] border border-[#E5E7EB] dark:border-[#1E293B] hover:border-[#CBD5E1] dark:hover:border-[#334155] text-xs font-mono transition-all duration-200 ease-[cubic-bezier(0.22,1,0.36,1)] hover:-translate-y-0.5 active:scale-[0.98]"
              >
                <ExternalLink className="w-3.5 h-3.5 text-[#64748B]" />
                <span>Live Demo</span>
              </a>
            )}
          </div>
        </header>

        {/* Hero Visual Image / Screenshot Mockup */}
        <div className="overflow-hidden rounded-2xl shadow-xs">
          <ProjectVisual project={project} isHero={true} />
        </div>

        {/* 1. Overview */}
        <section className="space-y-2.5">
          <h2 className="text-xs font-mono uppercase tracking-wider text-[#6F88B5] font-bold flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5" />
            <span>OVERVIEW / 项目背景与定位</span>
          </h2>
          <p className="text-xs sm:text-sm text-[#374151] dark:text-[#CBD5E1] font-light leading-relaxed p-4 bg-[#FFFFFF] dark:bg-[#131B2E] border border-[#E5E7EB] dark:border-[#1E293B] rounded-xl">
            {project.overview}
          </p>
        </section>

        {/* 2. Key Features */}
        <section className="space-y-2.5">
          <h2 className="text-xs font-mono uppercase tracking-wider text-[#6F88B5] font-bold flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>CORE FEATURES / 核心功能与特性</span>
          </h2>
          <div className="space-y-2">
            {project.features.map((feature, i) => (
              <div
                key={i}
                className="p-3 bg-[#FFFFFF] dark:bg-[#131B2E] border border-[#E5E7EB] dark:border-[#1E293B] rounded-xl flex items-start gap-2.5 text-xs sm:text-sm text-[#374151] dark:text-[#CBD5E1]"
              >
                <span className="text-[#6F88B5] font-mono font-bold text-xs mt-0.5">0{i + 1}</span>
                <span className="leading-relaxed">{feature}</span>
              </div>
            ))}
          </div>
        </section>

        {/* 3. Tech Stack */}
        <section className="space-y-2.5">
          <h2 className="text-xs font-mono uppercase tracking-wider text-[#6F88B5] font-bold">
            TECH STACK / 技术选型
          </h2>
          <div className="flex flex-wrap gap-2">
            {project.techStack.map((tech) => (
              <Badge key={tech} label={tech} category={project.category} size="md" />
            ))}
          </div>
        </section>

        {/* 4. Development Notes */}
        <section className="space-y-2.5">
          <h2 className="text-xs font-mono uppercase tracking-wider text-[#6F88B5] font-bold flex items-center gap-1.5">
            <Cpu className="w-3.5 h-3.5" />
            <span>DEVELOPMENT NOTES / 架构思考与开发笔记</span>
          </h2>
          <div className="p-4 bg-[#FFFFFF] dark:bg-[#131B2E] border border-[#E5E7EB] dark:border-[#1E293B] rounded-xl text-xs sm:text-sm text-[#374151] dark:text-[#CBD5E1] font-light leading-relaxed">
            {project.developmentNotes}
          </div>
        </section>

        {/* 5. Challenges & Solutions */}
        {project.challengesSolutions && project.challengesSolutions.length > 0 && (
          <section className="space-y-2.5">
            <h2 className="text-xs font-mono uppercase tracking-wider text-[#6F88B5] font-bold">
              CHALLENGES & SOLUTIONS / 难点与解法
            </h2>
            <div className="space-y-2.5">
              {project.challengesSolutions.map((item, idx) => (
                <div
                  key={idx}
                  className="p-4 bg-[#FFFFFF] dark:bg-[#131B2E] border border-[#E5E7EB] dark:border-[#1E293B] rounded-xl space-y-1.5 text-xs sm:text-sm"
                >
                  <div className="text-[#111827] dark:text-[#F9FAFB] font-medium flex items-baseline gap-2">
                    <span className="text-rose-500 dark:text-rose-400 font-mono text-xs shrink-0">挑战:</span>
                    <span>{item.challenge}</span>
                  </div>
                  <div className="text-[#4B5563] dark:text-[#94A3B8] font-light pl-6 leading-relaxed flex items-baseline gap-2">
                    <span className="text-emerald-600 dark:text-emerald-400 font-mono text-xs shrink-0">解法:</span>
                    <span>{item.solution}</span>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Bottom Links */}
        <div className="pt-6 border-t border-[#E5E7EB] dark:border-[#1E293B] flex items-center justify-between">
          <Link
            to="/projects"
            className="text-xs font-mono text-[#64748B] dark:text-[#94A3B8] hover:text-[#111827] dark:hover:text-white flex items-center gap-1 transition-colors"
          >
            <ArrowLeft className="w-3 h-3" />
            <span>返回项目列表</span>
          </Link>

          <a
            href={project.githubUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs font-mono text-[#111827] dark:text-[#F9FAFB] hover:text-[#6F88B5] flex items-center gap-1 transition-colors font-medium"
          >
            <span>在 GitHub 上查看源码</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </a>
        </div>
      </article>
    </div>
  );
};
