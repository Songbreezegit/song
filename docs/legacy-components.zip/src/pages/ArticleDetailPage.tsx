import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, Clock, Calendar, Check, Copy, ArrowRight } from 'lucide-react';
import { ARTICLES } from '../data/portfolioData';
import { Badge } from '../components/Badge';

export const ArticleDetailPage = () => {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [scrollProgress, setScrollProgress] = useState(0);

  const currentIndex = ARTICLES.findIndex((a) => a.slug === slug);
  const article = ARTICLES[currentIndex];

  const prevArticle = currentIndex > 0 ? ARTICLES[currentIndex - 1] : null;
  const nextArticle = currentIndex < ARTICLES.length - 1 ? ARTICLES[currentIndex + 1] : null;

  useEffect(() => {
    const handleScroll = () => {
      const totalScroll = document.documentElement.scrollHeight - window.innerHeight;
      if (totalScroll > 0) {
        setScrollProgress((window.scrollY / totalScroll) * 100);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  if (!article) {
    return (
      <div className="py-24 max-w-2xl mx-auto px-4 text-center space-y-4">
        <h1 className="text-xl font-serif text-[#111827] dark:text-white">文章未找到</h1>
        <p className="text-sm text-[#64748B] dark:text-[#94A3B8]">所请求的文章或技术笔记不存在或已被归档。</p>
        <button
          onClick={() => navigate('/articles')}
          className="px-4 py-2 bg-[#111827] dark:bg-white text-white dark:text-[#111827] rounded-lg text-xs font-mono cursor-pointer"
        >
          返回文章列表
        </button>
      </div>
    );
  }

  const handleCopyCode = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <div className="relative py-10 sm:py-16">
      {/* Top Reading Progress Bar with smooth editorial ease */}
      <div
        className="fixed top-0 left-0 h-[2px] bg-[#6F88B5] dark:bg-[#8EAAEC] z-50 transition-all duration-150 ease-out pointer-events-none"
        style={{ width: `${scrollProgress}%` }}
      />

      <article className="max-w-2xl mx-auto px-4 sm:px-6 page-reveal">
        {/* Navigation back */}
        <div className="mb-6">
          <Link
            to="/articles"
            className="inline-flex items-center gap-1.5 text-xs font-mono text-[#64748B] dark:text-[#94A3B8] hover:text-[#111827] dark:hover:text-white transition-colors group"
          >
            <ArrowLeft className="w-3.5 h-3.5 group-hover:-translate-x-1 transition-transform duration-200" />
            <span>Articles / 全部文章</span>
          </Link>
        </div>

        {/* Article Header & Metadata */}
        <header className="mb-8 pb-6 border-b border-[#E5E7EB] dark:border-[#1E293B] space-y-3">
          <div className="flex flex-wrap items-center gap-2.5 text-xs font-mono text-[#64748B] dark:text-[#94A3B8]">
            <Badge label={article.category} category={article.category} size="sm" />
            <span className="flex items-center gap-1">
              <Calendar className="w-3 h-3 text-[#9CA3AF]" />
              <span>{article.date}</span>
            </span>
            <span className="flex items-center gap-1">
              <Clock className="w-3 h-3 text-[#9CA3AF]" />
              <span>{article.readTime}</span>
            </span>
          </div>

          <h1 className="text-2xl sm:text-3xl md:text-4xl font-serif font-medium text-[#111827] dark:text-[#F9FAFB] leading-tight tracking-tight">
            {article.title}
          </h1>

          <p className="text-sm sm:text-base text-[#64748B] dark:text-[#94A3B8] font-light leading-relaxed">
            {article.subtitle}
          </p>

          <div className="flex flex-wrap items-center gap-1.5 pt-1">
            {article.tags.map((tag) => (
              <span
                key={tag}
                className="text-[11px] font-mono text-[#64748B] dark:text-[#94A3B8] px-2 py-0.5 bg-[#FFFFFF] dark:bg-[#131B2E] border border-[#E5E7EB] dark:border-[#1E293B] rounded"
              >
                #{tag}
              </span>
            ))}
          </div>
        </header>

        {/* Editorial Lead Paragraph */}
        <div className="mb-8 text-sm sm:text-base text-[#374151] dark:text-[#CBD5E1] font-light leading-relaxed p-4 bg-[#FFFFFF] dark:bg-[#131B2E] border-l-2 border-[#6F88B5] border-y border-r border-[#E5E7EB] dark:border-[#1E293B] rounded-r-xl">
          {article.content.lead}
        </div>

        {/* Article Content Stream */}
        <div className="space-y-8 text-sm sm:text-base text-[#374151] dark:text-[#CBD5E1] leading-relaxed font-light">
          {article.content.sections.map((section, sIndex) => (
            <section key={sIndex} className="space-y-3">
              {section.heading && (
                <h2 className="text-lg sm:text-xl font-serif font-medium text-[#111827] dark:text-[#F9FAFB] pt-3 pb-1 border-b border-[#E5E7EB]/60 dark:border-[#1E293B]/60">
                  {section.heading}
                </h2>
              )}

              {section.body.map((p, pIndex) => (
                <p key={pIndex} className="leading-relaxed">
                  {p}
                </p>
              ))}

              {/* Code Snippet Block with hover highlight and micro-scale copy feedback */}
              {section.code && (
                <div className="my-5 rounded-xl overflow-hidden border border-[#E5E7EB] dark:border-[#1E293B] hover:border-[#6F88B5]/40 hover:shadow-xs transition-all duration-200 bg-[#0F172A] text-[#F8FAFC] font-mono text-xs">
                  <div className="flex items-center justify-between px-4 py-2 bg-[#1E293B] text-[11px] text-[#94A3B8] border-b border-[#334155]/60 select-none">
                    <span>{section.code.filename || section.code.language}</span>
                    <button
                      onClick={() => handleCopyCode(section.code!.snippet, sIndex)}
                      className="flex items-center gap-1 hover:text-white transition-all duration-150 active:scale-95 cursor-pointer"
                    >
                      {copiedIndex === sIndex ? (
                        <span className="flex items-center gap-1 text-emerald-400 animate-in fade-in zoom-in-95 duration-150">
                          <Check className="w-3 h-3 text-emerald-400" />
                          <span>Copied</span>
                        </span>
                      ) : (
                        <span className="flex items-center gap-1">
                          <Copy className="w-3 h-3" />
                          <span>Copy</span>
                        </span>
                      )}
                    </button>
                  </div>
                  <pre className="p-4 overflow-x-auto leading-relaxed text-xs">
                    <code>{section.code.snippet}</code>
                  </pre>
                </div>
              )}

              {/* Data Table */}
              {section.table && (
                <div className="my-4 overflow-x-auto rounded-xl border border-[#E5E7EB] dark:border-[#1E293B] bg-[#FFFFFF] dark:bg-[#131B2E]">
                  <table className="w-full text-left text-xs font-mono border-collapse">
                    <thead>
                      <tr className="border-b border-[#E5E7EB] dark:border-[#1E293B] bg-[#F9FAFB] dark:bg-[#1A233A] text-[#374151] dark:text-[#E2E8F0]">
                        {section.table.headers.map((h, i) => (
                          <th key={i} className="p-3 font-semibold">
                            {h}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#E5E7EB] dark:divide-[#1E293B]">
                      {section.table.rows.map((row, rIndex) => (
                        <tr key={rIndex} className="hover:bg-[#F9FAFB]/60 dark:hover:bg-[#1A233A]/60">
                          {row.map((cell, cIndex) => (
                            <td key={cIndex} className="p-3 text-[#4B5563] dark:text-[#94A3B8]">
                              {cell}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {/* Blockquote */}
              {section.quote && (
                <blockquote className="my-5 pl-4 border-l-2 border-[#6F88B5] italic text-[#4B5563] dark:text-[#94A3B8] font-serif text-base">
                  {section.quote}
                </blockquote>
              )}

              {/* Callout Notice */}
              {section.callout && (
                <div className="my-3.5 p-3.5 rounded-xl bg-[#F0F4FA] dark:bg-[#152238] border border-[#D0DBEC] dark:border-[#1E3A63] text-xs font-sans text-[#243354] dark:text-[#93B4E2] leading-relaxed flex items-start gap-2">
                  <span className="text-[#6F88B5] font-bold shrink-0">ℹ</span>
                  <span>{section.callout.text}</span>
                </div>
              )}
            </section>
          ))}
        </div>

        {/* Article Bottom Navigation */}
        <div className="mt-12 pt-8 border-t border-[#E5E7EB] dark:border-[#1E293B] grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
          {prevArticle ? (
            <Link
              to={`/articles/${prevArticle.slug}`}
              className="p-3.5 rounded-xl bg-[#FFFFFF] dark:bg-[#131B2E] border border-[#E5E7EB] dark:border-[#1E293B] hover:border-[#6F88B5] dark:hover:border-[#6F88B5] transition-all duration-200 group"
            >
              <div className="text-[#9CA3AF] mb-1 flex items-center gap-1">
                <ArrowLeft className="w-3 h-3 group-hover:-translate-x-1 transition-transform duration-200" />
                <span>上一篇 / Previous</span>
              </div>
              <div className="font-serif text-xs sm:text-sm font-medium text-[#111827] dark:text-[#F9FAFB] group-hover:text-[#6F88B5] transition-colors line-clamp-1">
                {prevArticle.title}
              </div>
            </Link>
          ) : (
            <div />
          )}

          {nextArticle && (
            <Link
              to={`/articles/${nextArticle.slug}`}
              className="p-3.5 rounded-xl bg-[#FFFFFF] dark:bg-[#131B2E] border border-[#E5E7EB] dark:border-[#1E293B] hover:border-[#6F88B5] dark:hover:border-[#6F88B5] transition-all duration-200 group sm:text-right"
            >
              <div className="text-[#9CA3AF] mb-1 flex items-center justify-end gap-1">
                <span>下一篇 / Next</span>
                <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform duration-200" />
              </div>
              <div className="font-serif text-xs sm:text-sm font-medium text-[#111827] dark:text-[#F9FAFB] group-hover:text-[#6F88B5] transition-colors line-clamp-1">
                {nextArticle.title}
              </div>
            </Link>
          )}
        </div>
      </article>
    </div>
  );
};
